﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InstagarmBot.Models
{
   public class BaseModel
    {
        public int   UserId { get; set; }
    
        
        
        
    }
}
